#' allen.archaeology: A package for applying Allen's interval algebra to Bayesian calibration output
#'
#' The allen.archaeology package provides three categories of functions:
#' illustrate, plot, and describe.
#'
#' @section Illustrate function:
#' The illustrate function ...
#'
#' @section Plot functions:
#' The plot functions ...
#'
#' @section Describe function:
#' The describe function ...
#'
#' @docType package
#' @name allen.archaeology
NULL
# > NULL
