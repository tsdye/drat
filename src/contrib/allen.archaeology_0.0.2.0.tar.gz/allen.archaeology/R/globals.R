utils::globalVariables(c("node", "result"))
