#' Make a single plot of a Nökel lattice.
#'
#' Plots a Nökel lattice to the display and optionally to a file.
#'
#' @param allen_set a dataframe with plot information, such as the one
#' produced by \code{illustrate_allen_relations()}
#' @param file_name optional path to the graphic file output
#' @param pad padding in inches to the margins to keep
#' labels from disappearing off the edge of the graphic
#' @param font_size font size for the labels in the plot
#' @param height height in inches of the graphic file output
#' @param width width in inches of the graphic file output
#' @param plot_title title for the plot, defaults to the title in \code{allen_set}
#' @param columns number of columns for a plot with more than one lattice
#'
#' @return called for its side effects
#'
#' @author Thomas S. Dye
#'
#' @importFrom graphics title
#' @importFrom ggplot2 .pt aes facet_wrap ggsave ggtitle labs vars xlim ylim
#' @importFrom ggplot2 theme
#'
allen_plot <- function(allen_set, file_name = NULL, pad = 0.2, font_size = 11,
    height = 7, width = 7, columns = 1, plot_title = allen_set$title) {
    if (!(is.data.frame(allen_set)))
        stop("Unrecognized data for N\u00F6kel lattice.")
    g <- ggraph::ggraph(graph = allen_set, layout = "nicely")
    g <- g + ggraph::theme_graph()
    min_x <- min(allen_set$x)
    max_x <- max(allen_set$x)
    g <- g + xlim(min_x - pad, max_x + pad)
    min_y <- min(allen_set$y)
    max_y <- max(allen_set$y)
    g <- g + ylim(min_y - pad, max_y + pad)
    if(dim(allen_set)[1] == 13)
        g <- g + ggtitle(plot_title)
    else
        g <- g + facet_wrap(vars(title), ncol = columns)
    g <- g + khroma::scale_colour_iridescent()
    g <- g + ggraph::geom_node_label(mapping = aes(label = node, colour = result ),
                                     fill = "#DDDDDD",
                                     data = allen_set,
                                     size = font_size/.pt)
    if (is.illustration.vector(allen_set$result)) {
        g <- g + theme(legend.position = "none")
    } else {
        g <- g + labs(colour = "Posterior\nprobability")
    }
    if (!is.null(file_name))
        ggsave(filename = file_name, plot = g, device = grDevices::cairo_pdf, height = height,
            width = width)
    g
}
