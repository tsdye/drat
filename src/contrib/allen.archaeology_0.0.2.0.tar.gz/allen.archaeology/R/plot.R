#' Plot a Nokel lattice
#'
#'

#' Plot a panel of Nokel lattices
#'
