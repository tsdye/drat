library(testthat)
library(allen.archaeology)

test_check("allen.archaeology")
